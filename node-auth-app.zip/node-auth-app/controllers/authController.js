const jwt = require('jsonwebtoken');
const User = require('../models/user.js');
const sendEmail = require('../utils/sendEmail');
const config = require('../config');
const bcrypt = require('bcryptjs');

const register = async (req, res) => {
    try {
        const { userName, fullName, emailId, lab, role, password, memorableInfo } = req.body;
        let user = await User.findOne({ where: { userName } });
        if (user) {
            return res.status(400).json({ message: `User ${user.userName} already exists` });
        }
        user = await User.create({ userName, fullName, emailId, lab, role, password, memorableInfo });
        res.status(201).json({ message: `User ${user.userName} registered successfully` });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const login = async (req, res) => {
    try {
        const { userName, password } = req.body;
        const user = await User.findOne({ where: { userName } });

        if (!user) {
            return res.status(401).json({ message: 'User not found' });
        } else if (!(await user.comparePassword(password))) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user.userName, role: user.role }, config.jwtSecret, { expiresIn: '30m' }
        );
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const forgotPassword = async (req, res) => {
    try {
        const { userName, newPassword, memorableInfo } = req.body;
        const user = await User.findOne({ where: { userName } });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const isMemorableInfoValid = await user.compareMemorableInfo(memorableInfo);
        if (!isMemorableInfoValid) {
            return res.status(400).json({ message: 'Memorable information does not match' });
        }

        if ((await user.comparePassword(newPassword))) {
            return res.status(400).json({ message: 'New password cannot be same as old password' });
        }

        user.password = newPassword;
        await user.save();

        setImmediate(async () => {
            try {
                await sendEmail(
                    user.emailId,
                    'Password Reset',
                    `Hello ${user.fullName}, your password has been reset successfully.`
                );
            } catch (error) {
                console.error('Error sending email:', error);
            }
        });

        res.json({ message: 'Password reset successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = { register, login, forgotPassword };
