const { Sequelize } = require('sequelize');
const config = require('../config');

const sequelize = new Sequelize(config.mysql.database, config.mysql.user, config.mysql.password, {
    host: config.mysql.host,
    dialect: 'mysql',
    port: config.mysql.port,
});

const initializeDatabase = async () => {
    try {
        await sequelize.authenticate();
        console.log('MySQL connected');
        await sequelize.sync({ alter: true });
        console.log('MySQL tables synced');
    } catch (err) {
        console.error('MySQL connection error:', err);
    }
};

initializeDatabase();

module.exports = sequelize;
