const nodemailer = require('nodemailer');
const config = require('../config');

const sendEmail = async (to, subject, text) => {
    const transporter = nodemailer.createTransport({
        service: config.emailService,
        auth: {
            user: config.emailUser,
            pass: config.emailPass,
        },
    });

    const mailOptions = {
        from: config.emailUser,
        to,
        subject,
        text,
    };

    await transporter.sendMail(mailOptions);
};

module.exports = sendEmail;
